$('.inner span').click(function(){
	$('.inner').removeClass('cur');
	$(this).parent().addClass('cur');
});
$('.select_list').mouseleave(function(){
	$('.inner').removeClass('cur');
});

$('.select_list ul li').click(function(){
	$(this).parents('.inner').find('span').eq(0).html($(this).html());
	$('.inner').removeClass('cur');
})

$(".table_switching ul li").click(function(){
	$(".table_switching ul li").removeClass('cur');
	$(this).addClass('cur');
})
$('.contract').click(function(){
	$(".tableList1").show();
	$(".tableList2").hide();
})
$('.unsigned').click(function(){
	$(".tableList1").hide();
	$(".tableList2").show();
})

//时间插件
	var laydate = layui.laydate;
 
	laydate.render({ 
	  elem: '#test1',
	  done: function(value, date, endDate){
	    console.log(value); //得到日期生成的值，如：2017-08-18
	  }
	  ,showBottom: false
	});
	laydate.render({ 
	  elem: '#endtest'
	  ,min: '2010-01-01'
	  ,max: '2080-10-01'
	  ,showBottom: false
	  ,done: function(value, date, endDate){
	    console.log(value); //得到日期生成的值，如：2017-08-18
	   
	  }
	  
	
	});