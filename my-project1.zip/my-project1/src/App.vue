<!--1模板：html结构-->
<template>
  <div id="app">
		<router-view></router-view>
  </div>
</template>
<!--2行为：处理逻辑-->
<script>


export default {
  name: 'App', //传值只会变化一个
	data(){
	  return {
      
      
      
    }
	  	
	 },
  components: {
  	
  },
  methods:{
 		
 	}
  
  
}

</script>
<!--样式-->
<style scoped>
h1{
	color: red;
}
</style>
