
import Vue from 'vue'
import VueRouter from 'vue-router'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min.js';
import iView from 'iview';
import 'iview/dist/styles/iview.css'; 
import App from './App'
import routes  from './router/router'
import store from './store/store.js';
/*import '../static/layui/layui.js';*/
import '../static/layui/css/layui.css'
import '../static/css/base.css'
import Time from './components/time'
import Axios from 'axios'

Vue.prototype.$axios = Axios
Axios.defaults.baseURL = '/api'
Axios.defaults.headers.post['Content-Type'] = 'application/json';
Vue.config.productionTip = false

Vue.use(VueRouter);
Vue.use(iView);


Vue.component('Time', Time);

//配置路由
const router = new VueRouter({
	routes:routes,
	mode:'history'
})

router.beforeEach((to, from, next) => {
    next();
});

router.afterEach((to, from, next) => {
    window.scrollTo(0, 0);
});

new Vue({
	router,
  store,
  el: '#app',
  components: { App },
  template: '<App/>'
})
