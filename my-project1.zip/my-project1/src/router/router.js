
import HelloWorld from '../components/HelloWorld'
import Home from '../components/Home'
import Home1 from '../components/Home1'
import Home2 from '../components/Home2'
export default [
  {path:'/',component:Home},
  {path:'/helloworld',component:HelloWorld},
  {path:'/Home1',component:Home1},
  {path:'/Home2',component:Home2}
]
