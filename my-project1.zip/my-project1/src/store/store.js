import Vuex from 'vuex';
import Vue from 'vue'
Vue.use(Vuex);
const state={
  usersa:[
    {name:'herry',position:'web开发',show:false},
    {name:'bucky',position:'web开发',show:true},
    {name:'emily',position:'web开发',show:true},
    {name:'lily',position:'web开发',show:false},
    {name:'herry',position:'web开发',show:false},
    {name:'bucky',position:'web开发',show:true},
    {name:'emily',position:'web开发',show:true},
    {name:'bucky',position:'web开发',show:true},
    {name:'emily',position:'web开发',show:true},
    {name:'lily',position:'web开发',show:false},
    {name:'zhufei',position:'web开发',show:false},

  ],
  hello:'oy'

}
const mutations={

  changeBase(e,obj){
    debugger;
    let {attr,val}=obj;
    state[attr]=val
  }
}

const  actions={

}

export default  new Vuex.Store({
  state,
  mutations,
  actions
})
