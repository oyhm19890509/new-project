<!--1模板：html结构-->
<template>
  <div id="app">
       <div class="layout">
       	 <Layout>
            <Header>
                <Menu mode="horizontal" theme="dark" active-name="1">
                    <div class="layout-logo"></div>
                    <div class="layout-nav">
                        <MenuItem name="1">
                            <Icon type="ios-navigate"></Icon>
                            Item 1
                        </MenuItem>
                        <MenuItem name="2">
                            <Icon type="ios-keypad"></Icon>
                            Item 2
                        </MenuItem>
                        <MenuItem name="3">
                            <Icon type="ios-analytics"></Icon>
                            Item 3
                        </MenuItem>
                        <MenuItem name="4">
                            <Icon type="ios-paper"></Icon>
                            Item 4
                        </MenuItem>
                    </div>
                </Menu>
            </Header>
            <Layout>
            		 <Sider hide-trigger :style="{background: '#fff'}">
					            <i-menu :theme="theme2" active-name="1-1" width="auto" :open-names="['1']" @on-select='add'>
					                <submenu name="1">
					                    <template slot="title">
					                        <icon type="ios-paper" />
					                        内容管理
					                    </template>
					                    <menu-item name="1-1">文章管理</menu-item>
					                    <menu-item name="1-2">评论管理</menu-item>
					                    <menu-item name="1-3">举报管理</menu-item>
					                </submenu>
					                <submenu name="2">
					                    <template slot="title">
					                        <icon type="ios-people" />
					                        用户管理
					                    </template>
					                    <menu-item name="2-1">新增用户</menu-item>
					                    <menu-item name="2-2">活跃用户</menu-item>
					                </submenu>
					                <submenu name="3">
					                    <template slot="title">
					                        <icon type="ios-stats" />
					                        统计分析
					                    </template>
					                    <menu-group title="使用">
					                        <menu-item name="3-1">新增和启动</menu-item>
					                        <menu-item name="3-2">活跃分析</menu-item>
					                        <menu-item name="3-3">时段分析</menu-item>
					                    </menu-group>
					                    <menu-group title="留存">
					                        <menu-item name="3-4">用户留存</menu-item>
					                        <menu-item name="3-5">流失用户</menu-item>
					                    </menu-group>
					                </submenu>
					            </i-menu>
					        </Sider>
									
                <div :style="{padding: '0 24px 24px'}" class="my-content">
                    <Breadcrumb :style="{margin: '24px 0'}">
                        <BreadcrumbItem>Home</BreadcrumbItem>
                        <BreadcrumbItem>Components</BreadcrumbItem>
                        <BreadcrumbItem>Layout</BreadcrumbItem>
                    </Breadcrumb>
                    <div class="" :style="{padding: '24px', minHeight: '200px', background: '#fff'}">
                        <component v-bind:is="TabComponent" v-bind:usersb='usersa'></component>
                    </div>
                </div>
       		</Layout>
        </Layout>
      </div>
  </div>
</template>
<!--2行为：处理逻辑-->
<script>

import Users from './users'
import Header from './header'
import Footer from './footer'
import axios from 'axios';

export default {
  name: 'app', //传值只会变化一个
  data(){
  	return {
  		theme2: 'light',
  		TabComponent:'Users',
  	}
  },
  mounted(){
    //方法一：
      /*axios.get('https://dis.tianyancha.com/dis/timeline.json?id=2312611345')
      .then(function(response){
        console.log(response.data);
      })
      .catch(function(err){
        console.log(err);
      });*/
      //方法二
    var that=this;
    axios.get('https://dis.tianyancha.com/dis/timeline.json',{
      params:{
        id:2312611345
      }
    })
      .then(function(response){
        console.log(response.data.data.nodes);
        that.data=response.data.data.nodes;

      })
      .catch(function(err){
        console.log(err);
      });


  },
  computed:{
	    usersa(){
	      debugger;
	      return this.$store.state.usersa
	    },
	    hello(){
	      return this.$store.state.hello
	    }
	  
  },
  components: {
  	'Users':Users,
  	'app-header':Header,
    'app-footer':Footer
  },
	directives: {  //自定义指令
	  focus: {
	    // 指令的定义
	    inserted: function (el) {
	      el.focus()
	    }
	  }
	},
  methods:{
	 		//title1  子向父组件传值demo
	 		updateTitle:function(title1){
	 			this.title = title1;
	 		},
	 		changeobject(){
	 			this.userProfile = Object.assign({}, this.userProfile, {
				  age: 27,
				  favoriteColor: 'Vue Green'
				})
	 		},
	    add(a){
				if (a=='1-1') {
					this.TabComponent='Users'
				} else if(a=='1-2'){
					this.TabComponent='app-header'
				}else{
					this.TabComponent='app-footer'
				}
			
	    },
	    open(index,item){
	    	 this.num = index;
	    	 this.configNav.forEach(i=>{
	    	 	 // 判断如果数据中的menuList[i]的show属性不等于当前数据的isSubShow属性那么menuList[i]等于false 
		    	 if (i.isSubShow !=this.configNav[index].isSubShow ) {
		    	 		 i.isSubShow = false; 
		    	 	}
		    	 	 
	    	 })
	    	 item.isSubShow = !item.isSubShow; 
	    	
	  
	    },
	    open1(nav){
         this.linkClick = nav.link;
	  
	    },
    change(){
      debugger;
      this.$store.commit("changeBase",{
        attr:'hello',
        val:'feifei'
      })
    }
 	}


}

</script>
<!--样式-->

<style scoped type="text/css" src='../../static/css/home.css'></style>
<style scoped type="text/css">

.my-content{
	width: 100%;
}
.layout{
    border:none;
    background: #f5f7f9;
    position: relative;
    border-radius: 4px;
    overflow: hidden;
}
.l
.layout-logo{
    width: 100px;
    height: 30px;
    background: #5b6270;
    border-radius: 3px;
    float: left;
    position: relative;
    top: 15px;
    left: 20px;
}
.layout-nav{
    width: 420px;
    margin: 0 auto;
    margin-right: 20px;
}
</style>
