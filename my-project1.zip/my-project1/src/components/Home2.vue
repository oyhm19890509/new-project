<!--1模板：html结构-->
<template>
  <div id="home">
    <h3 @click="change" class="big">{{hello}}</h3>
  <div class="layout">
        <Layout>
            <Header>
                <Menu mode="horizontal" theme="dark" active-name="1">
                    <div class="layout-logo"></div>
                    <div class="layout-nav">
                        <MenuItem name="1">
                            <Icon type="ios-navigate"></Icon>
                            Item 1
                        </MenuItem>
                        <MenuItem name="2">
                            <Icon type="ios-keypad"></Icon>
                            Item 2
                        </MenuItem>
                        <MenuItem name="3">
                            <Icon type="ios-analytics"></Icon>
                            Item 3
                        </MenuItem>
                        <MenuItem name="4">
                            <Icon type="ios-paper"></Icon>
                            Item 4
                        </MenuItem>
                    </div>
                </Menu>
            </Header>
            <Layout>
                <Sider hide-trigger :style="{background: '#fff'}">
                    <Menu active-name="1-2" theme="light" width="auto" :open-names="['1']">
                        <Submenu name="1">
                            <template slot="title">
                                <Icon type="ios-navigate"></Icon>
                                Item 1
                            </template>
                            <MenuItem name="1-1">Option 1</MenuItem>
                            <MenuItem name="1-2">Option 2</MenuItem>
                            <MenuItem name="1-3">Option 3</MenuItem>
                        </Submenu>
                        <Submenu name="2">
                            <template slot="title">
                                <Icon type="ios-keypad"></Icon>
                                Item 2
                            </template>
                            <MenuItem name="2-1">Option 1</MenuItem>
                            <MenuItem name="2-2">Option 2</MenuItem>
                        </Submenu>
                        <Submenu name="3">
                            <template slot="title">
                                <Icon type="ios-analytics"></Icon>
                                Item 3
                            </template>
                            <MenuItem name="3-1">Option 1</MenuItem>
                            <MenuItem name="3-2">Option 2</MenuItem>
                        </Submenu>
                    </Menu>
                </Sider>
                <Layout :style="{padding: '0 24px 24px'}">
                    <Breadcrumb :style="{margin: '24px 0'}">
                        <BreadcrumbItem>Home</BreadcrumbItem>
                        <BreadcrumbItem>Components</BreadcrumbItem>
                        <BreadcrumbItem>Layout</BreadcrumbItem>
                    </Breadcrumb>
                    <Content :style="{padding: '24px', minHeight: '280px', background: '#fff'}">
                        Content
                    </Content>
                </Layout>
            </Layout>
        </Layout>
    </div>
    <input v-focus >
		<app-header v-on:titleChange='updateTitle($event)' v-bind:title='title'></app-header>
		<!--动态组件-->
		 <component v-bind:is="TabComponent" v-bind:usersb='usersa'></component>
   <!-- <Users v-bind:usersb='usersa'></Users>-->
   <!-- <Users v-bind:usersb='usersa'></Users>-->
    <app-footer v-bind:title='title'></app-footer>
    <ul >
      <li v-for="item in data" v-bind:aitem="item">{{item.id}}</li>
    </ul>
    <ul >
      <li v-for="item in items" v-if="item.isComplete">{{item.message}}</li>
    </ul>
    <button @click="add">添加</button>
    <ul >
      <li v-for="item in userProfile">{{item}}</li>
      <button @click="changeobject">对象更改</button>
    </ul>
  </div>
</template>
<!--2行为：处理逻辑-->
<script>
//import HelloWorld from './components/HelloWorld'
import Users from './users'
import Header from './header'
import Footer from './footer'
import axios from 'axios';

export default {
  name: 'Home', //传值只会变化一个
  data(){
  	return {
  		TabComponent:'Users',
      title:'传递的是一个值',
      data:'',
      items: [
        { message: 'Foo',isComplete:true },
        { message: 'Bar',isComplete:false },
        { message: 'Har',isComplete:true }
      ],
       userProfile: {
	      name: 'Anika'
	    }
  	}
  },
  mounted(){
    //方法一：
      /*axios.get('https://dis.tianyancha.com/dis/timeline.json?id=2312611345')
      .then(function(response){
        console.log(response.data);
      })
      .catch(function(err){
        console.log(err);
      });*/
      //方法二
    var that=this;
    axios.get('https://dis.tianyancha.com/dis/timeline.json',{
      params:{
        id:2312611345
      }
    })
      .then(function(response){
        console.log(response.data.data.nodes);
        that.data=response.data.data.nodes;

      })
      .catch(function(err){
        console.log(err);
      });


  },
  computed:{
	    usersa(){
	      debugger;
	      return this.$store.state.usersa
	    },
	    hello(){
	      return this.$store.state.hello
	    }
	  /* ,TabComponent () {
	      return 'Users'
	    }*/
  },
  components: {
  	'Users':Users,
  	'app-header':Header,
    'app-footer':Footer
  },
	directives: {  //自定义指令
	  focus: {
	    // 指令的定义
	    inserted: function (el) {
	      el.focus()
	    }
	  }
	},
  methods:{
	 		//title1  子向父组件传值demo
	 		updateTitle:function(title1){
	 			this.title = title1;
	 		},
	 		changeobject(){
	 			this.userProfile = Object.assign({}, this.userProfile, {
				  age: 27,
				  favoriteColor: 'Vue Green'
				})
	 		},
	    add(){
	    	
	    	//新增数数组
	 		  /*this.items.push({
	        message: 'lili'
	        ,isComplete:true
	      })*/   
	      //过滤新数组含有o的项
	     /*this.items = this.items.filter(function (item) {
				  return item.message.match(/o/)
				})*/
				//替换数组中的某一项
			//	this.items.splice(0, 1, { message: 'rury',isComplete:true })
			//改变数组的长度
				this.items.splice(1);
	    },
    change(){
      debugger;
      this.$store.commit("changeBase",{
        attr:'hello',
        val:'feifei'
      })
    }
 	}


}

</script>
<!--样式-->

<style scoped type="text/css" src='../../static/css/home.css'></style>
<style scoped type="text/css">
.layout{
    border: 1px solid #d7dde4;
    background: #f5f7f9;
    position: relative;
    border-radius: 4px;
    overflow: hidden;
}
.layout-logo{
    width: 100px;
    height: 30px;
    background: #5b6270;
    border-radius: 3px;
    float: left;
    position: relative;
    top: 15px;
    left: 20px;
}
.layout-nav{
    width: 420px;
    margin: 0 auto;
    margin-right: 20px;
}
</style>
