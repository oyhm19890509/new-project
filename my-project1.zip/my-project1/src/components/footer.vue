<template>
  <footer>
  	<h1>{{title1}}{{title}}</h1>
  	<h2></h2>
  </footer>
</template>

<script>
export default {
  name: 'app-footer1',
  props:['title'],
  data () {
    return {
      title1:'2017demo'

    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
footer{
	text-align: center;
	color: #fff;
	padding: 10px;
	background-color:#000 ;
}
</style>
