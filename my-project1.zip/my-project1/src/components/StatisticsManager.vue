<template>
	<div id='app-main' class="content-body">
		<div class='statisticsTop clearfix'>
			<h1 class="left">统计结算</h1>
			<div class="right">
				<span>本月交易流水：<b>18000元</b></span>
				<span>本月交易流水：<b>500元</b></span>
			</div>
		</div>
		<div class="search_bar">	
			<div class="block">
				<span class="search">查找</span>
				<div class="inner">
					<span>产品名称</span>
					<div class="select_list">
						<ul>
							<li>产品名称</li>
							<li>产品名称</li>
							<li>产品名称</li>
							<li>产品名称</li>
							<li>产品名称</li>
							<li>产品名称</li>
							<li>产品名称</li>
							<li>产品名称</li>
							<li>产品名称</li>
						</ul>
					</div>
				</div>
				<div class="inner"><input type="text" placeholder="请输入产品名称" /></div>
			</div>
			<Time></Time>		
			<!--<div class="block">
				<span class="time">操作时间</span>
				<div class="inner">
					<input type="text" class="layui-input" id="test1" placeholder="开始时间"  readonly="true">
					
				</div>
				<div class="inner">
					<input type="text" class="layui-input" id="endtest" placeholder="结束时间"  readonly="true">
					
				</div>
			</div>-->
			<div class="block"><button class="green btn_search">搜索</button></div>
			<div class="block"><button class="green btn_export">导出</button></div>
		</div>
	
	    <div class="tableList">
			<div class="table_outer">
	        <table class="table">
	          <thead>
	            <tr>
	              <th>序号</th><th>客户名称</th><th>交易笔数</th><th>交易金额</th><th>佣金率</th><th>佣金</th>
	            </tr>
	          </thead>
	          <tbody>
	            <tr><td>1</td><td>奥拓</td><td>523笔</td><td>100000元</td><td>0.06%</td><td>100元</td></tr>
	            <tr><td>2</td><td>奥拓</td><td>523笔</td><td>100000元</td><td>0.06%</td><td>100元</td></tr>         
	            <tr><td>3</td><td>奥拓</td><td>523笔</td><td>100000元</td><td>0.06%</td><td>100元</td></tr>         
	            <tr><td>4</td><td>奥拓</td><td>523笔</td><td>100000元</td><td>0.06%</td><td>100元</td></tr>
	            <tr><td>5</td><td>奥拓</td><td>523笔</td><td>100000元</td><td>0.06%</td><td>100元</td></tr>
	          	<tr><td>6</td><td>奥拓</td><td>523笔</td><td>100000元</td><td>0.06%</td><td>100元</td></tr>         
	            <tr><td>7</td><td>奥拓</td><td>523笔</td><td>100000元</td><td>0.06%</td><td>100元</td></tr>
	            <tr><td>8</td><td>奥拓</td><td>523笔</td><td>100000元</td><td>0.06%</td><td>100元</td></tr>
	          </tbody>
	        </table>
			</div>
			<div class="footer">
			 	<div id="demo"></div>
			</div>
	    </div>
	</div>
</template>

<script>
	
import Time from './time'
export default {
  name: 'app-main',
   props:['title'],
  data () {
    return {
     nowIndex:0,
      states:['已签约客户','未签约客户']

    }
  },
  components: {
  	Time
  },
  methods:{
  	tab(item,index){
  		this.nowIndex=index;
  	}
  },
  mounted:function(){
  		var element = layui.element;
		var layer = layui.layer;
		var laypage = layui.laypage;
		  laypage.render({
		    elem: 'demo'
		    ,count: 100
		    ,prev: '<em><</em>'
		    ,next: '<em>></em>'
		    ,first: '首页'
		    ,last: '尾页'
	      	,jump: function(obj, first){
		      if(!first){
		        layer.msg('第 '+ obj.curr +' 页');
		      }
		    }
		  });
		  
		  
		  
		  var laypage = layui.laypage;
		  laypage.render({
		    elem: 'demo1'
		    ,count: 100
		    ,prev: '<em><</em>'
		    ,next: '<em>></em>'
		    ,first: '首页'
		    ,last: '尾页'
	      	,jump: function(obj, first){
		      if(!first){
		        layer.msg('第 '+ obj.curr +' 页');
		      }
		    }
		  });
		  
		//时间插件
		var laydate = layui.laydate;
	 
		laydate.render({ 
		  elem: '#test1',
		  done: function(value, date, endDate){
		    console.log(value); //得到日期生成的值，如：2017-08-18
		  }
		  ,showBottom: false
		});
		laydate.render({ 
		  elem: '#endtest'
		  ,min: '2010-01-01'
		  ,max: '2080-10-01'
		  ,showBottom: false
		  ,done: function(value, date, endDate){
		    console.log(value); //得到日期生成的值，如：2017-08-18
		   
		  }
		  
		
		});
  }
}
</script>

<style scoped type="text/css" src='../../static/css/search_bar.css'></style>
<style scoped type="text/css" src='../../static/css/statistics.css'></style>

<style scoped>


	
</style>
