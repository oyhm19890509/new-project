<template>
  <header @click="changeTitle">
  	<h1>{{title1}}{{title}}</h1>
  </header>
</template>

<script>
export default {
  name: 'app-header',
   props:['title'],
  data () {
    return {
      title1:'vue.js'

    }
  },
  methods:{
  	changeTitle:function(){
  		//this.title ='改变'  ,$emit  注册事件，也就是自定义事件跟click一个差不多的事件
  		this.$emit('titleChange','子向父组件传值demo')
  	}
  }
  /*beforeCreate:function(){
  	alert('组件实例化之前执行的');
  },
  created:function(){
  	alert('组件实例化完毕，单页面还未显示');
  },
  beforeMount:function(){
  	alert('组件实例化完毕，单页面还未显示，但是虚拟Dom已经配置');
  },
  mounted:function(){
  	alert('此方法执行后，页面显示');
  },
  beforeUpdate:function(){
  	alert('组件更新前，页面扔未更新，但是虚拟Demo已经配置');
  },
  updated:function(){
  	alert('组件更新后，此方法执行完，页面显示');
  },
  beforeDestory:function(){
  	alert('组件销毁前更新后，此方法执行完，页面显示');
  },
  destoryed:function(){
  	alert('组件销毁');
  }*/
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
header{
	text-align: center;
	padding: 10px;
	color: #fff;
	background-color:#f40 ;
}
</style>
