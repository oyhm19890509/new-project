<template>
	<div id='app-main' class="content-body">
			<div class='statisticsTop clearfix'>
				<h1 class="left">账户状态</h1>
			</div>
			 <div class="incontent-one">
					<ul class="layui-row incontent-row">
						<li class="layui-col-xs6">
							<h1>交易流水</h1>
							<div>总交易流水  500000元<span>/</span>本月交易流水  500000元</div>
						</li>
						<li class="layui-col-xs6">
							<h1 class="number1">开户数量</h1>
							<div>总开户数  500家<span>/</span>本月开户数  120家</div>
						</li>
						
					</ul>
				</div>
			
				
				<div class="search_bar">
					<div class="block"><button class="blue btn_build" id="build">新建</button></div>
					
					<div class="block">
						<span class="search">查找</span>
						<div class="inner">
							<span>客户名称</span>
							<input style="display: none;" type="text" value="" />
							<div class="select_list">
								<ul>
									<li data-info = "aaa1">客户名称1</li>
									<li data-info = "aaa2">客户名称2</li>
									<li data-info = "aaa3">客户名称3</li>
									<li data-info = "aaa4">客户名称4</li>
									<li data-info = "aaa5">客户名称5</li>
									<li data-info = "aaa6">客户名称6</li>
									<li data-info = "aaa7">客户名称7</li>
									<li data-info = "aaa8">客户名称8</li>
									<li data-info = "aaa9">客户名称9</li>
								</ul>
							</div>
						</div>
						<div class="inner"><input type="text" placeholder="请输入客户名称" /></div>
					</div>
					
					<div class="block">
						<span class="time">创建时间</span>
						<div class="inner">
							<input type="text" class="layui-input" id="test1" placeholder="开始时间"  readonly="true">
							
						</div>
						<div class="inner">
							<input type="text" class="layui-input" id="endtest" placeholder="结束时间"  readonly="true">
							
						</div>
					</div>
					
					<div class="block"><button class="green btn_search">搜索</button></div>
					
					<div class="block"><button class="green btn_export">导入</button></div>
					
				</div>
				
				<div class="table_switching clearfix">
					<ul >
						<li v-for="(item,index) in states" :class="{cur:index==nowIndex}" @click="tab(item,index)">{{item}}</li>
					
						<!--<li class="contract cur" >已签约客户</li>
						<li class="unsigned">待签约客户</li>-->
					</ul>
				</div>
				 <!--客户管理表格---已签约客户-->
			    <div class="tableList tableList1" v-show="nowIndex==0">
					<div class="table_outer">
			        <table class="table">
			          <thead>
			            <tr>
			              <th>序号</th><th>客户名称</th><th>联系方式</th><th>客户来源</th><th>营业员</th><th>证件号</th><th>状态</th><th>创建时间</th><th>签约额度</th><th>剩余额度</th><th>操作</th>
			            </tr>
			          </thead>
			          <tbody>
			            <tr><td>1</td><td>奥托</td><td>18907151234</td><td>企业</td><td>刘梅</td><td>420106198701152345</td><td>正常</td><td>2017.02.23 14:22:42</td><td>100000元</td><td>2600元</td><td><a href="customer-manager-detail.html">查看</a>|<a href="customer-manager-setting.html">配置</a>|<a href="contract-manager-build.html">添加子合同</a></td></tr>
			            <tr><td>2</td><td>奥托</td><td>18907151234</td><td>企业</td><td>刘梅</td><td>420106198701152345</td><td>正常</td><td>2017.02.23 14:22:42</td><td>100000元</td><td>2600元</td><td><a href="###">查看</a>|<a href="###">配置</a>|<a href="###">添加子合同</a></td></tr>
			            <tr><td>3</td><td>奥托</td><td>18907151234</td><td>企业</td><td>刘梅</td><td>420106198701152345</td><td>正常</td><td>2017.02.23 14:22:42</td><td>100000元</td><td>2600元</td><td><a href="###">查看</a>|<a href="###">配置</a>|<a href="###">添加子合同</a></td></tr>
			            <tr><td>4</td><td>奥托</td><td>18907151234</td><td>企业</td><td>刘梅</td><td>420106198701152345</td><td>正常</td><td>2017.02.23 14:22:42</td><td>100000元</td><td>2600元</td><td><a href="###">查看</a>|<a href="###">配置</a>|<a href="###">添加子合同</a></td></tr>
			            <tr><td>5</td><td>奥托</td><td>18907151234</td><td>企业</td><td>刘梅</td><td>420106198701152345</td><td>正常</td><td>2017.02.23 14:22:42</td><td>100000元</td><td>2600元</td><td><a href="###">查看</a>|<a href="###">配置</a>|<a href="###">添加子合同</a></td></tr>
			          </tbody>
			        </table>
					</div>
					<div class="footer">
					 	<div id="demo"></div>
					</div>
			    </div>
			    
			    
			    <!--客户管理表格---待签约客户-->
			    <div class="tableList tableList2" v-show="nowIndex==1">
					<div class="table_outer">
			        <table class="table">
			          <thead>
			            <tr>
			              <th>序号</th><th>客户名称</th><th>联系方式</th><th>客户来源</th><th>营业员</th><th>证件号</th><th>状态</th><th>创建时间</th><th>签约额度</th><th>剩余额度</th><th>操作</th>
			            </tr>
			          </thead>
			          <tbody>
			            <tr><td>1</td><td>奥托</td><td>18907151234</td><td>企业</td><td>刘梅</td><td>420106198701152345</td><td>未认领</td><td>2017.02.23 14:22:42</td><td></td><td></td><td><a href="customer-manager-detail.html">查看</a>|<a href="customer-manager-accept.html">认领</a>|<a class="signColor" href="contract-manager-build.html">添加子合同</a></td></tr>
			            <tr><td>2</td><td>奥美</td><td>18907151234</td><td>普通</td><td>刘梅</td><td>420106198701152345</td><td>联络中</td><td>2017.02.23 14:22:42</td><td></td><td></td><td><a href="###">查看</a>|<a class="signColor" href="###">认领</a>|<a href="###">添加子合同</a></td></tr>
			            <tr><td>3</td><td>长江云</td><td>18907151234</td><td>企业</td><td>刘梅</td><td>934125451123</td><td>未认领</td><td>2017.02.23 14:22:42</td><td></td><td></td><td><a href="###">查看</a>|<a href="###">认领</a>|<a class="signColor" href="###">添加子合同</a></td></tr>
			          	<tr><td>1</td><td>长江云</td><td>18907151234</td><td>普通</td><td>刘梅</td><td>420106198701152345</td><td>联络中</td><td>2017.02.23 14:22:42</td><td></td><td></td><td><a href="###">查看</a>|<a class="signColor" href="###">认领</a>|<a href="###">添加子合同</a></td></tr>
			            <tr><td>2</td><td>长江云</td><td>18907151234</td><td>企业</td><td>刘梅</td><td>934125451123</td><td>未认领</td><td>2017.02.23 14:22:42</td><td></td><td></td><td><a href="###">查看</a>|<a href="###">认领</a>|<a class="signColor" href="###">添加子合同</a></td></tr>
			          </tbody>
			        </table>
					</div>
					<div class="footer">
					 	<div id="demo1"></div>
					</div>
			    </div>
			
				<div class="pop01">
					<div class="bg"></div>
					<div class="popContent">
						<div class="poptitle">请导入客户信息<img class="delete02" src="../../static/images/delete02.png" alt="" /></div>
						<div class="info_main list_two">
							<div class="list">
								<div class="tit">展示文件名</div>
								<div class="info1">
									<button class="blue">选择文件</button>
									<input id="imgUP" type="file" accept="image/*" />
									<span class="fileName">未选择任何文件</span>
								</div>
							</div>
						</div>
						 <div class="btnD"><button @click="downloadExl(jsono)">点击下载excel示例</button></div>
						<div class="btn_bar">
							<button class="green confirm">确定</button>
						</div>
					</div>
				</div>
			
			 
	</div>
</template>

<script>
export default {
  name: 'app-main',
   props:['title'],
  data () {
    return {
     nowIndex:0,
      states:['已签约客户','未签约客户']

    }
  },
  methods:{
  	tab(item,index){
  		this.nowIndex=index;
  	}
  },
  mounted:function(){
  		var element = layui.element;
		var layer = layui.layer;
		var laypage = layui.laypage;
		  laypage.render({
		    elem: 'demo'
		    ,count: 100
		    ,prev: '<em><</em>'
		    ,next: '<em>></em>'
		    ,first: '首页'
		    ,last: '尾页'
	      	,jump: function(obj, first){
		      if(!first){
		        layer.msg('第 '+ obj.curr +' 页');
		      }
		    }
		  });
		  
		  
		  
		  var laypage = layui.laypage;
		  laypage.render({
		    elem: 'demo1'
		    ,count: 100
		    ,prev: '<em><</em>'
		    ,next: '<em>></em>'
		    ,first: '首页'
		    ,last: '尾页'
	      	,jump: function(obj, first){
		      if(!first){
		        layer.msg('第 '+ obj.curr +' 页');
		      }
		    }
		  });
		  
		//时间插件
		var laydate = layui.laydate;
	 
		laydate.render({ 
		  elem: '#test1',
		  done: function(value, date, endDate){
		    console.log(value); //得到日期生成的值，如：2017-08-18
		  }
		  ,showBottom: false
		});
		laydate.render({ 
		  elem: '#endtest'
		  ,min: '2010-01-01'
		  ,max: '2080-10-01'
		  ,showBottom: false
		  ,done: function(value, date, endDate){
		    console.log(value); //得到日期生成的值，如：2017-08-18
		   
		  }
		  
		
		});
  }
}
</script>

<style scoped type="text/css" src='../../static/css/search_bar.css'></style>
<style scoped type="text/css" src='../../static/css/statistics.css'></style>

<style scoped>


	
</style>
