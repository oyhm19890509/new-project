<template>
  <div class="block">
			<span class="time">操作时间</span>
			<div class="inner">
				<input type="text" class="layui-input" id="test1" placeholder="开始时间"  readonly="true">
				
			</div>
			<div class="inner">
				<input type="text" class="layui-input" id="endtest" placeholder="结束时间"  readonly="true">
				
			</div>
			<div class="inner">
				<input type="text" placeholder="请输入姓名">
				
			</div>
		</div>
</template>

<script>
	//引用：arry abect
	/*传值：string number*/
export default {
	
  name: '',

  props:['usersb'],//属性传值,父组件向子组件传递数据

	methods:{
 		
	 },
	   mounted:function(){
  	
		  
		//时间插件
		var laydate = layui.laydate;
	 
		laydate.render({ 
		  elem: '#test1',
		  done: function(value, date, endDate){
		    console.log(value); //得到日期生成的值，如：2017-08-18
		  }
		  ,showBottom: true
		});
		laydate.render({ 
		  elem: '#endtest'
		  ,min: '2010-01-01'
		  ,max: '2080-10-01'
		  ,showBottom: true
		  ,done: function(value, date, endDate){
		    console.log(value); //得到日期生成的值，如：2017-08-18
		   
		  }
		  
		
		});
  },
  data () {
    return {



    }
  }
}
</script>
<style scoped type="text/css" src='../../static/css/search_bar.css'></style>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
