<template>
  <div class="users">
  	<h1> HELLO users</h1>
  	<ul>
  		<li v-for="(user,key,index) in usersb"

  			v-on:click="user.show=!user.show">
  			<h1>{{user.name}}</h1>
  			<h2 v-show="user.show">{{user.position}}</h2>

  		</li>
  	</ul>
  	<button v-on:click='deleteU'>
  		删除
  	</button>
  </div>

</template>

<script>
	//引用：arry abect
	/*传值：string number*/
export default {
  name: 'Users',

  props:['usersb'],//属性传值,父组件向子组件传递数据

	methods:{
 		deleteU:function(){
	 			this.usersb.pop();
	 	} 

	 	
	 	
	 },
  data () {
    return {



    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1{
	color: green;
}
.users{
	width: 100%;
	max-width: 1200px;
	margin: 40px auto;
	padding: 0 20px;
	box-sizing: border-box;
}
ul{
	display: flex;
	flex-wrap: wrap;
	list-style-type: none;
	padding: 0;

}
li{
	flex-grow: 1;
	flex-basis: 200px;
	/*flex: 1;*/
	text-align: center;
	padding: 30px;
	border: 1px solid #222;
	margin: 10px;
}
</style>
