<template>
    <div id='app-main' class="content-body">
			<div class='statisticsTop clearfix'>
				<h1 class="left">订单管理</h1>
				<div class="right">
					<span>本月交易流水：<b>18000元</b></span>
					<span>本月交易流水：<b>500元</b></span>
				</div>
			</div>
			
			<div class="search_bar">
				<div class="block">
					<span class="search">查找</span>
					<div class="inner">
						<span>产品名称</span>
						<div class="select_list">
							<ul>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
							</ul>
						</div>
					</div>
					<div class="inner"><input type="text" placeholder="请输入产品名称" /></div>
				</div>
				
				<div class="block">
					<span class="state">状态</span>
					<div class="inner">
						<span>成功</span>
						<div class="select_list">
							<ul>
								<li>成功</li>
								<li>失败</li>
							</ul>
						</div>
					</div>
				</div>
				
				<!--<div class="block">
					<span class="time">创建时间</span>
					<div class="inner">
						<input type="text" class="layui-input" id="test1" placeholder="开始时间"  readonly="true">
						
					</div>
					<div class="inner">
						<input type="text" class="layui-input" id="endtest" placeholder="结束时间"  readonly="true">
						
					</div>
				</div>-->
				<Time></Time>		
				
				<div class="block"><button class="green btn_search">搜索</button></div>
				
				<div class="block"><button class="green btn_export">导出</button></div>
			</div>
			
			<div class="tableList">
				<div class="table_outer">
		        <table class="table">
		          <thead>
		            <tr>
		              <th>序号</th><th>订单编号</th><th>产品名称</th><th>产品类别</th><th>价格</th><th>实收金额</th><th>佣金</th><th>支付方式</th><th>用户</th><th>联系电话</th><th>状态</th><th>创建时间</th><th>操作</th>
		            </tr>
		          </thead>
		          <tbody>
		            <tr><td>1</td><td>20180415145</td><td>云主机</td><td>计算</td><td>10元</td><td>9.98元</td><td>0.02</td><td>话费支付</td><td>奥拓</td><td>18907151234</td><td>成功</td><td>2017.02.23 14:22:43</td><td><a href="order-info.html">查看</a></td></tr>
		            <tr><td>2</td><td>20180415145</td><td>对象存储</td><td>数据</td><td>1099元</td><td>1098.5</td><td>1.5</td><td>支付宝支付</td><td>奥拓</td><td>18907151234</td><td>已付款</td><td>2017.02.23 14:22:43</td><td><a href="###">查看</a></td></tr>
		          	<tr><td>3</td><td>20180415145</td><td>云主机</td><td>计算</td><td>10元</td><td>9.98元</td><td>0.02</td><td>话费支付</td><td>奥拓</td><td>18907151234</td><td>成功</td><td>2017.02.23 14:22:43</td><td><a href="###">查看</a></td></tr>
		            <tr><td>4</td><td>20180415145</td><td>对象存储</td><td>数据</td><td>1099元</td><td>1098.5</td><td>1.5</td><td>支付宝支付</td><td>奥拓</td><td>18907151234</td><td>已付款</td><td>2017.02.23 14:22:43</td><td><a href="###">查看</a></td></tr>
		            <tr><td>5</td><td>20180415145</td><td>云主机</td><td>计算</td><td>10元</td><td>9.98元</td><td>0.02</td><td>话费支付</td><td>奥拓</td><td>18907151234</td><td>成功</td><td>2017.02.23 14:22:43</td><td><a href="###">查看</a></td></tr>
		            <tr><td>6</td><td>20180415145</td><td>对象存储</td><td>数据</td><td>1099元</td><td>1098.5</td><td>1.5</td><td>支付宝支付</td><td>奥拓</td><td>18907151234</td><td>已付款</td><td>2017.02.23 14:22:43</td><td><a href="###">查看</a></td></tr>
		            <tr><td>7</td><td>20180415145</td><td>云主机</td><td>计算</td><td>10元</td><td>9.98元</td><td>0.02</td><td>话费支付</td><td>奥拓</td><td>18907151234</td><td>成功</td><td>2017.02.23 14:22:43</td><td><a href="###">查看</a></td></tr>
		            <tr><td>8</td><td>20180415145</td><td>对象存储</td><td>数据</td><td>1099元</td><td>1098.5</td><td>1.5</td><td>支付宝支付</td><td>奥拓</td><td>18907151234</td><td>已付款</td><td>2017.02.23 14:22:43</td><td><a href="###">查看</a></td></tr>
		          </tbody>
		        </table>
				</div>
				<div class="footer">
				 	<div id="demo"></div>
				</div>
		    </div>
	
    </div>
</template>

<script>
 export default {
        data() {
            return {
            }
                
        },
        mounted:function(){
	  		var element = layui.element;
			var layer = layui.layer;
			var laypage = layui.laypage;
			  laypage.render({
			    elem: 'demo'
			    ,count: 100
			    ,prev: '<em><</em>'
			    ,next: '<em>></em>'
			    ,first: '首页'
			    ,last: '尾页'
		      	,jump: function(obj, first){
			      if(!first){
			        layer.msg('第 '+ obj.curr +' 页');
			      }
			    }
			  });
			  
			  //时间插件
				var laydate = layui.laydate;
			 
				laydate.render({ 
				  elem: '#test1',
				  done: function(value, date, endDate){
				    console.log(value); //得到日期生成的值，如：2017-08-18
				  }
				  ,showBottom: true
				});
				laydate.render({ 
				  elem: '#endtest'
				  ,min: '2010-01-01'
				  ,max: '2080-10-01'
				  ,showBottom: true
				  ,done: function(value, date, endDate){
				    console.log(value); //得到日期生成的值，如：2017-08-18
				   
				  }
				  
				
				});
		  },
        methods: {
            changeli: function(ind, item) {
                // 先循环数据中的show将其全部置为false,此时模板里的v-if判断生效关闭全部二级菜单,并移除样式
                this.headerData.forEach(i => {
                    // 判断如果数据中的headerData[i]的show属性不等于当前数据的show属性那么headerData[i]等于false
                    if (i.show !== this.headerData[ind].show) {
                        i.show = false;
                    };
                });
                // 取反(true或false)
                item.show = !item.show;
                console.log(item.name)
            },
            doThis: function(index) {
                alert(index)
            }
        }
    }
</script>
<style scoped type="text/css" src='../../static/css/search_bar.css'></style>
<style scoped type="text/css" src='../../static/css/statistics.css'></style>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>


</style>
