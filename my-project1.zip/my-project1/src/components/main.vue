<template>
	<div id='app-main' class="content-body">
		<div class='top clearfix'>
				<h1 class="left index-top-left">账户状态</h1>
				<div class="right">
					<span class="index-top-right index-top-right-one">当前等级：一级代理</span>
					<span class="index-top-right index-top-right-two"><i class="index-top-right-two-icon"></i>申请升级</span>
				</div>
			</div>
			<div class="incontent-one">
				<ul class="layui-row incontent-row">
					<li class="layui-col-xs4">
						<h1>交易流水</h1>
						<div>总流水交易&nbsp;500000元</div>
						<div>本月流水交易&nbsp;500000元</div>
					</li>
					<li class="layui-col-xs4">
						<h1 class="money1">佣金</h1>
						<div>总佣金&nbsp;500000元</div>
						<div>本月佣金&nbsp;500000元</div>
					</li>
					<li class="layui-col-xs4">
						<h1 class="number1">开户数量</h1>
						<div>总开户数量&nbsp;500000元</div>
						<div>本月开户数量&nbsp;500000元</div>
					</li>
				</ul>
			</div>
			<div class="incontent-two clearfix">
				<div class="left incontent-two-con incontent-two-left ">
					<h1 class="clearfix">
						<span class="left">近6个月的交易流水</span>
						<span class="right"><a href="statistics-manager.html">详情+</a></span>
					</h1>
					<div class="layui-form">
					  <table class="layui-table" lay-skin="line">
					    <colgroup>
					      <col >
					      <col >
					      
					    </colgroup>
					    <thead>
					      <tr>
					        <th>月</th>
					        <th>交易流水</th>
					        
					      </tr> 
					    </thead>
					    <tbody>
					      <tr>
					        <td>2018.9</td>
					        <td>100</td>
					        
					      </tr>
					      <tr>
					        <td>2018.9</td>
					        <td>100</td>
				      	  </tr>
				      	  <tr>
					        <td>2018.9</td>
					        <td>100</td>
				      	  </tr>
				      	  <tr>
					        <td>2018.9</td>
					        <td>100</td>
				      	  </tr>
				      	  <tr>
					        <td>2018.9</td>
					        <td>100</td>
				      	  </tr>
					      <tr>
					        <td>2018.9</td>
					        <td>100</td>
				      	  </tr>
					    </tbody>
					  </table>
					</div>
				</div>
				<div class="right incontent-two-con incontent-two-right">
					<h1 class="clearfix">
						<span class="left number1">近6个月的交易数量</span>
						<span class="right"><a href="statistics-manager.html">详情+</a></span>
					</h1>
					<div class="layui-form">
					  <table class="layui-table" lay-skin="line">
					    <colgroup>
					      <col >
					      <col >
					      
					    </colgroup>
					    <thead>
					      <tr>
					        <th>月</th>
					        <th>交易数量</th>
					        
					      </tr> 
					    </thead>
					    <tbody>
					      <tr>
					        <td>2018.9</td>
					        <td>100</td>
					        
					      </tr>
					      <tr>
					        <td>2018.9</td>
					        <td>100</td>
				      	  </tr>
				      	  <tr>
					        <td>2018.9</td>
					        <td>100</td>
				      	  </tr>
				      	  <tr>
					        <td>2018.9</td>
					        <td>100</td>
				      	  </tr>
				      	  <tr>
					        <td>2018.9</td>
					        <td>100</td>
				      	  </tr>
					      <tr>
					        <td>2018.9</td>
					        <td>100</td>
				      	  </tr>
					    </tbody>
					  </table>
					</div>
				</div>
			</div>
			
	
	
	</div>
</template>

<script>
export default {
  name: 'app-main',
   props:['title'],
  data () {
    return {
      title1:'vue.js'

    }
  },
  methods:{
  	changeTitle:function(){
  		//this.title ='改变'  ,$emit  注册事件，也就是自定义事件跟click一个差不多的事件
  		this.$emit('titleChange','子向父组件传值demo')
  	}
  }
  /*beforeCreate:function(){
  	alert('组件实例化之前执行的');
  },
  created:function(){
  	alert('组件实例化完毕，单页面还未显示');
  },
  beforeMount:function(){
  	alert('组件实例化完毕，单页面还未显示，但是虚拟Dom已经配置');
  },
  mounted:function(){
  	alert('此方法执行后，页面显示');
  },
  beforeUpdate:function(){
  	alert('组件更新前，页面扔未更新，但是虚拟Demo已经配置');
  },
  updated:function(){
  	alert('组件更新后，此方法执行完，页面显示');
  },
  beforeDestory:function(){
  	alert('组件销毁前更新后，此方法执行完，页面显示');
  },
  destoryed:function(){
  	alert('组件销毁');
  }*/
}
</script>

<style scoped type="text/css" src='../../static/css/index.css'></style>
<style scoped>
header{
	text-align: center;
	padding: 10px;
	color: #fff;
	background-color:#f40 ;
}

</style>
