<template>
	<div id='app-main' class="content-body">
			<div class='top clearfix '>
				<h1 class="left index-top-left">账户管理</h1>
				<div class="right">
					<span class="index-top-right index-top-right-one">账户余额：<b>18000元</b></span>
					<span class="index-top-right index-top-right-two" id="TiXian"><i class="index-top-right-two-icon"></i>提现</span>
				</div>
			</div>
			<div class="search_bar">
		
				<div class="block">
					<span class="search">查找</span>
					<div class="inner">
						<span>产品名称</span>
						<div class="select_list">
							<ul>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
								<li>产品名称</li>
							</ul>
						</div>
					</div>
					<div class="inner"><input type="text" placeholder="请输入产品名称" /></div>
				</div>
		
		
				<div class="block">
					<span class="time">操作时间</span>
					<div class="inner">
						<input type="text" class="layui-input" id="test1" placeholder="开始时间"  readonly="true">
						
					</div>
					<div class="inner">
						<input type="text" class="layui-input" id="endtest" placeholder="结束时间"  readonly="true">
						
					</div>
				</div>
		
				<div class="block"><button class="green btn_search">搜索</button></div>
		
			</div>
		    <!--账户管理表格-->
		    <div class="tableList">
				<div class="table_outer">
		        <table class="table">
		          <thead>
		            <tr>
		              <th>序号</th><th>交易号</th><th>提现金额</th><th>开户行</th><th>开户姓名</th><th>银行卡号</th><th>创建时间</th>
		            </tr>
		          </thead>
		          <tbody>
		            <tr><td>1</td><td>123123</td><td>123100元</td><td>湖北武汉市招商银行</td><td>科大讯飞</td><td>9797411315487</td><td>2017.02.23 14:23:43</td></tr>
		            <tr><td>2</td><td>123123</td><td>123100元</td><td>湖北武汉市招商银行</td><td>科大讯飞</td><td>9797411315487</td><td>2017.02.23 14:23:43</td></tr>
		            <tr><td>3</td><td>123123</td><td>123100元</td><td>湖北武汉市招商银行</td><td>科大讯飞</td><td>9797411315487</td><td>2017.02.23 14:23:43</td></tr>
		            <tr><td>4</td><td>123123</td><td>123100元</td><td>湖北武汉市招商银行</td><td>科大讯飞</td><td>9797411315487</td><td>2017.02.23 14:23:43</td></tr>
		            <tr><td>5</td><td>123123</td><td>123100元</td><td>湖北武汉市招商银行</td><td>科大讯飞</td><td>9797411315487</td><td>2017.02.23 14:23:43</td></tr>
		            <tr><td>6</td><td>123123</td><td>123100元</td><td>湖北武汉市招商银行</td><td>科大讯飞</td><td>9797411315487</td><td>2017.02.23 14:23:43</td></tr>
		            <tr><td>7</td><td>123123</td><td>123100元</td><td>湖北武汉市招商银行</td><td>科大讯飞</td><td>9797411315487</td><td>2017.02.23 14:23:43</td></tr>
		            <tr><td>8</td><td>123123</td><td>123100元</td><td>湖北武汉市招商银行</td><td>科大讯飞</td><td>9797411315487</td><td>2017.02.23 14:23:43</td></tr>
		          </tbody>
		        </table>
				</div>
				 <div class="footer">
				 	<div id="demo"></div>
				</div>
		    </div>
	</div>
</template>

<script>
export default {
  name: 'app-main',
   props:['title'],
  data () {
    return {
      title1:'vue.js'

    }
  },
  methods:{
  	changeTitle:function(){
  		//this.title ='改变'  ,$emit  注册事件，也就是自定义事件跟click一个差不多的事件
  		this.$emit('titleChange','子向父组件传值demo')
  	}
  },
  mounted:function(){
  		var element = layui.element;
		var layer = layui.layer;
		var laypage = layui.laypage;
		  laypage.render({
		    elem: 'demo'
		    ,count: 100
		    ,prev: '<em><</em>'
		    ,next: '<em>></em>'
		    ,first: '首页'
		    ,last: '尾页'
	      	,jump: function(obj, first){
		      if(!first){
		        layer.msg('第 '+ obj.curr +' 页');
		      }
		    }
		  });
		  
			  //时间插件
		var laydate = layui.laydate;
	 
		laydate.render({ 
		  elem: '#test1',
		  done: function(value, date, endDate){
		    console.log(value); //得到日期生成的值，如：2017-08-18
		  }
		  ,showBottom: false
		});
		laydate.render({ 
		  elem: '#endtest'
		  ,min: '2010-01-01'
		  ,max: '2080-10-01'
		  ,showBottom: false
		  ,done: function(value, date, endDate){
		    console.log(value); //得到日期生成的值，如：2017-08-18
		   
		  }
		  
		
		});
  }
}
</script>

<style scoped type="text/css" src='../../static/css/search_bar.css'></style>
<style scoped type="text/css" src='../../static/css/statistics.css'></style>
<style scoped>


	
</style>
