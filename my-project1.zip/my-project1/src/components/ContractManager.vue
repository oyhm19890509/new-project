<template>
	<div id='app-main' class="content-body">
			<div class='statisticsTop clearfix'>
				<h1 class="left">客户管理 — 合同管理</h1>
			</div>
			<div class="search_bar">
				<div class="block"><button id="build" class="blue btn_build">新建</button></div>
				<div class="block">
					<span class="search">查找</span>
					<div class="inner">
						<span>开户行</span>
						<div class="select_list">
							<ul>
								<li>开户行</li>
								<li>开户行</li>
								<li>开户行</li>
								<li>开户行</li>
								<li>开户行</li>
								<li>开户行</li>
								<li>开户行</li>
								<li>开户行</li>
								<li>开户行</li>
							</ul>
						</div>
					</div>
					<div class="inner"><input type="text" placeholder="请输入产品名称" /></div>
				</div>
				
				<div class="block">
					<span class="time">创建时间</span>
					<div class="inner">
						<input type="text" class="layui-input" id="test1" placeholder="开始时间"  readonly="true">
						
					</div>
					<div class="inner">
						<input type="text" class="layui-input" id="endtest" placeholder="结束时间"  readonly="true">
					</div>
				</div>
				<div class="block"><button class="green btn_search">搜索</button></div>
				<div class="block"><button class="green btn_export">导出</button></div>
			</div>
			
			<div class="tableList">
				<div class="table_outer">
			        <table class="table">
			          <thead>
			            <tr>
			              <th>序号</th><th>合同号</th><th>合同生效日期</th><th>客户</th><th>签约额度</th><th>可用额度</th><th>已用额度</th><th>剩余额度</th><th>审核状态</th><th>创建时间</th><th>操作</th>
			            </tr>
			          </thead>
			          <tbody>
			            <tr><td>1</td><td>HT4545131346</td><td>2018-5.31</td><td>北京悦动</td><td>500000.00元</td><td>500000.00元</td><td>300000.00元</td><td>20000.00元</td><td>已通过</td><td>2017.02.23  14:22:43</td><td><a href="contract-manager-info.html">查看</a>|<a class="signColor" href="###">审核</a></td></tr>
			            <tr><td>2</td><td>HT4545131346</td><td>2018-5.31</td><td>北京悦动</td><td>500000.00元</td><td>500000.00元</td><td>300000.00元</td><td>20000.00元</td><td>未审核</td><td>2017.02.23  14:22:43</td><td><a href="###">查看</a>|<a href="###">配置</a></td></tr>
			            <tr><td>3</td><td>HT4545131346</td><td>2018-5.31</td><td>北京悦动</td><td>500000.00元</td><td>500000.00元</td><td>300000.00元</td><td>20000.00元</td><td>已通过</td><td>2017.02.23  14:22:43</td><td><a href="###">查看</a>|<a class="signColor" href="###">审核</a></td></tr>
			            <tr><td>4</td><td>HT4545131346</td><td>2018-5.31</td><td>北京悦动</td><td>500000.00元</td><td>500000.00元</td><td>300000.00元</td><td>20000.00元</td><td>未审核</td><td>2017.02.23  14:22:43</td><td><a href="###">查看</a>|<a href="###">配置</a></td></tr>
			            <tr><td>5</td><td>HT4545131346</td><td>2018-5.31</td><td>北京悦动</td><td>500000.00元</td><td>500000.00元</td><td>300000.00元</td><td>20000.00元</td><td>已通过</td><td>2017.02.23  14:22:43</td><td><a href="###">查看</a>|<a class="signColor" href="###">审核</a></td></tr>
			            <tr><td>6</td><td>HT4545131346</td><td>2018-5.31</td><td>北京悦动</td><td>500000.00元</td><td>500000.00元</td><td>300000.00元</td><td>20000.00元</td><td>未审核</td><td>2017.02.23  14:22:43</td><td><a href="###">查看</a>|<a href="###">配置</a></td></tr>
			            <tr><td>7</td><td>HT4545131346</td><td>2018-5.31</td><td>北京悦动</td><td>500000.00元</td><td>500000.00元</td><td>300000.00元</td><td>20000.00元</td><td>已通过</td><td>2017.02.23  14:22:43</td><td><a href="###">查看</a>|<a class="signColor" href="###">审核</a></td></tr>
			            <tr><td>8</td><td>HT4545131346</td><td>2018-5.31</td><td>北京悦动</td><td>500000.00元</td><td>500000.00元</td><td>300000.00元</td><td>20000.00元</td><td>未审核</td><td>2017.02.23  14:22:43</td><td><a href="###">查看</a>|<a href="###">配置</a></td></tr>
					 </tbody>
					</table>
				</div>
				<div class="footer">
				 	<div id="demo"></div>
				</div>
		    </div>
	</div>
</template>

<script>
export default {
  name: 'app-main',
   props:['title'],
  data () {
    return {
     nowIndex:0,
      states:['已签约客户','未签约客户']

    }
  },
  methods:{
  	tab(item,index){
  		this.nowIndex=index;
  	}
  },
  mounted:function(){
  		var element = layui.element;
		var layer = layui.layer;
		var laypage = layui.laypage;
		  laypage.render({
		    elem: 'demo'
		    ,count: 100
		    ,prev: '<em><</em>'
		    ,next: '<em>></em>'
		    ,first: '首页'
		    ,last: '尾页'
	      	,jump: function(obj, first){
		      if(!first){
		        layer.msg('第 '+ obj.curr +' 页');
		      }
		    }
		  });
		  
		  
		  
		  var laypage = layui.laypage;
		  laypage.render({
		    elem: 'demo1'
		    ,count: 100
		    ,prev: '<em><</em>'
		    ,next: '<em>></em>'
		    ,first: '首页'
		    ,last: '尾页'
	      	,jump: function(obj, first){
		      if(!first){
		        layer.msg('第 '+ obj.curr +' 页');
		      }
		    }
		  });
		  
		//时间插件
		var laydate = layui.laydate;
	 
		laydate.render({ 
		  elem: '#test1',
		  done: function(value, date, endDate){
		    console.log(value); //得到日期生成的值，如：2017-08-18
		  }
		  ,showBottom: false
		});
		laydate.render({ 
		  elem: '#endtest'
		  ,min: '2010-01-01'
		  ,max: '2080-10-01'
		  ,showBottom: false
		  ,done: function(value, date, endDate){
		    console.log(value); //得到日期生成的值，如：2017-08-18
		   
		  }
		  
		
		});
  }
}
</script>

<style scoped type="text/css" src='../../static/css/search_bar.css'></style>
<style scoped type="text/css" src='../../static/css/statistics.css'></style>

<style scoped>


	
</style>
