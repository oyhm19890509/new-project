<!--1模板：html结构-->
<template>
  <div id="app">
       <div class="layout">
        <Layout>
            <Header >
                <Menu mode="horizontal"  theme="dark" active-name="1" >
                    <div class="layout-logo"></div>
                    <div class="layout-nav">
                        <MenuItem name="1" >
                            <Icon type="ios-navigate"></Icon>
                            Item 1
                        </MenuItem>
                        <MenuItem name="2">
                            <Icon type="ios-keypad"></Icon>
                            Item 2
                        </MenuItem>
                        <MenuItem name="3">
                            <Icon type="ios-analytics"></Icon>
                            Item 3
                        </MenuItem>
                        <MenuItem name="4">
                            <Icon type="ios-paper"></Icon>
                            Item 4
                        </MenuItem>
                    </div>
                </Menu>
            </Header>
            <Layout>
                <Sider hide-trigger :style="{background: '#fff'}">
	                <div class="ivu-layout-sider-children">
											<ul data-v-fed36922="" class="ivu-menu ivu-menu-light ivu-menu-vertical" style="width: auto;">
												<template  v-for="(item,index) in configNav">												
												<li  class="ivu-menu-submenu " v-bind:class="[index==num ? activeClass : '']" >
													<div class="ivu-menu-submenu-title"  @click="open(index,item)" ><i  class="ivu-icon ivu-icon-ios-keypad" v-bind:class="[index==num ? navigate :keypad]"></i> Item {{item.name}}
														<i class="ivu-icon ivu-icon-ios-arrow-down ivu-menu-submenu-title-icon" ></i></div>
													<ul class="ivu-menu" v-bind:class="[index==num ? '' : '']" v-show="item.isSubShow">
														<template v-for = "nav in item.subItems">
															<li @click="open1(nav)"  class="ivu-menu-item " v-bind:class="[nav.link==linkClick ? aselected :'' ]"  style="padding-left: 43px;">Option {{nav.text}}</li>
															<!--<li  class="ivu-menu-item" style="padding-left: 43px;">Option 2</li>-->
														</template>
													</ul>
												</li>
												
												</template>
												
											</ul>
										</div>
                  
                </Sider>
                <Layout>
                    <Breadcrumb :style="{margin: '24px 0'}">
                        <BreadcrumbItem>Home</BreadcrumbItem>
                        <BreadcrumbItem>Components</BreadcrumbItem>
                        <BreadcrumbItem>Layout</BreadcrumbItem>
                    </Breadcrumb>
                    <Content :style="{padding: '24px', minHeight: '500px', background: '#EBF2FA'}">
                        <component v-bind:is="TabComponent" v-bind:usersb='usersa'></component>
                    </Content>
                </Layout>
            </Layout>
        </Layout>
    </div>
  </div>
</template>
<!--2行为：处理逻辑-->
<script>

import Users from './users'
import Header from './header'
import Footer from './footer'
import Main from './main'
import AccountManager from './AccountManager'
import StatisticsManager from './StatisticsManager'
import HelloWorld from './HelloWorld'
import XMain from './main'
import CustomerManager from './CustomerManager'
import ContractManager from './ContractManager'
import axios from 'axios';


export default {
  name: 'app', //传值只会变化一个
  data(){
  	return {
  		TabComponent:'XMain',
      title:'传递的是一个值',
      data:'',
      num:'0',
      mytext:'',
      linkClick:'#/callSource',
       configNav:[
                    { 
                        name:'首页',
                        isSubShow:true, 
                        subItems:[
                       			{ link:'#/callSource',text: '首页' }
                       			
                        ]
                    },
                    { 
                        name:'账户管理',
                        isSubShow:false, 
                        subItems:[
                           { link:'#/org',text: '账户管理' }
                        ]
                    },  
                    { 
                        name:'客户管理',
                        isSubShow:false, 
                        subItems:[
                            { link:'#/org1',text: '客户管理' },
                            { link:'#/term',text: '合同管理' }
                        ]
                    },
                    { 
                        name:'订单管理',
                        isSubShow:false, 
                        subItems:[
                            { link:'#/term1',text: '订单管理' }
                        ]
                    },
                    { 
                        name:'统计管理',
                        isSubShow:false, 
                        subItems:[
                            { link:'#/term2',text: '统计管理' }
                        ]
                    }
                ],
 
      activeClass:'ivu-menu-opened',
      navigate:'ivu-icon-ios-navigate',
      keypad:' ivu-icon-ios-keypad',
      aselected:{
      	'ivu-menu-item-active':true,
      	'ivuMenuItemSelected':true
      },
      isActive:true,
      items: [
        { message: 'Foo',isComplete:true },
        { message: 'Bar',isComplete:false },
        { message: 'Har',isComplete:true }
      ],
       userProfile: {
	      name: 'Anika'
	    }
  	}
  },
  mounted(){
    //方法一：
      /*axios.get('https://dis.tianyancha.com/dis/timeline.json?id=2312611345')
      .then(function(response){
        console.log(response.data);
      })
      .catch(function(err){
        console.log(err);
      });*/
      //方法二
   /* var that=this;
    axios.get('https://dis.tianyancha.com/dis/timeline.json',{
      params:{
        id:2312611345
      }
    })
      .then(function(response){
        console.log(response.data.data.nodes);
        that.data=response.data.data.nodes;

      })
      .catch(function(err){
        console.log(err);
      });*/
     
		var that=this;
    that.$axios.get("/ajax/mgj.pc.detailinfo/v1?_ajax=1&itemId=1kq1pfa")
				.then(res=>{
					console.log(res)
				})
				.catch(err=>{
					console.log(err)
				})

  },
  computed:{
	    usersa(){
	      debugger;
	      return this.$store.state.usersa
	    },
	    hello(){
	      return this.$store.state.hello
	    }
	  /* ,TabComponent () {
	      return 'Users'
	    }*/
  },
  components: {
  	'Users':Users,
  	'app-header':Header,
    'app-footer':Footer,
    'XMain':Main,
    AccountManager,
    CustomerManager,
    HelloWorld,
    StatisticsManager,
    ContractManager
  },
	directives: {  //自定义指令
	  focus: {
	    // 指令的定义
	    inserted: function (el) {
	      el.focus()
	    }
	  }
	},
  methods:{
	 		//title1  子向父组件传值demo
	 		updateTitle:function(title1){
	 			this.title = title1;
	 		},
	 		changeobject(){
	 			this.userProfile = Object.assign({}, this.userProfile, {
				  age: 27,
				  favoriteColor: 'Vue Green'
				})
	 		},
	    add(name){
					switch(name)
				{
				case "1":
				 this.$router.push('/helloworld')
				  break;
				case "2":
				this.$router.push('/Home1')
				 // this.TabComponent='AccountManager'
				  break;
				case "3":
				this.$router.push('/Home2')
				// this.TabComponent='CustomerManager'
				  break;
				case "4":
				 this.TabComponent='ContractManager'
				  break;
				

				}
	    },
	    open(index,item){
	    	 this.num = index;
	    	 this.configNav.forEach(i=>{
	    	 	 // 判断如果数据中的menuList[i]的show属性不等于当前数据的isSubShow属性那么menuList[i]等于false 
		    	 if (i.isSubShow !=this.configNav[index].isSubShow ) {
		    	 		 i.isSubShow = false; 
		    	 	}
		    	 	 
	    	 })
	    	 item.isSubShow = !item.isSubShow; 
	    	
	  
	    },
	    open1(nav){
         this.linkClick = nav.link;
         this.mytext=nav.text;
        	switch(this.mytext)
				{
				case "首页":
				 this.TabComponent='XMain'
				  break;
				case "账户管理":
				  this.TabComponent='AccountManager'
				  break;
				case "客户管理":
				 this.TabComponent='CustomerManager'
				  break;
				case "合同管理":
				 this.TabComponent='ContractManager'
				  break;
				  case "订单管理":
				  this.TabComponent='HelloWorld'
				  break;
				  case "备案管理":
				  this.TabComponent='Users'
				  break;
				  case "统计管理":
				 this.TabComponent='StatisticsManager'
				  break;

				}
         
         
	  
	    },
    change(){
      debugger;
      this.$store.commit("changeBase",{
        attr:'hello',
        val:'feifei'
      })
    }
 	}


}

</script>
<!--样式-->

<style scoped type="text/css" src='../../static/css/home.css'></style>
<style scoped type="text/css">

.layout{
    border: 1px solid #d7dde4;
    background: #f5f7f9;
    position: relative;
    border-radius: 4px;
    overflow: hidden;
}
.layout-logo{
    width: 100px;
    height: 30px;
    background: #5b6270;
    border-radius: 3px;
    float: left;
    position: relative;
    top: 15px;
    left: 20px;
}
.layout-nav{
    width: 440px;
    margin: 0 auto;
    margin-right: 20px;
}
.ivu-layout-sider{
	height: 500px;
}
.ivu-breadcrumb{
	margin: 24px!important;
}
</style>
